/**
 * base-ui-styled
 *
 * Base UI components wrapped with `@emotion/styled`, pre-styled to match the
 * no-frills look from the official Base UI documentation. The CSS for each
 * component is ported verbatim from that component's "CSS Modules" example on
 * https://base-ui.com.
 *
 * Each component keeps the original Base UI API (parts, props, refs, the
 * `render` composition prop, and all `data-*` state attributes), so these are
 * drop-in replacements for the unstyled components — the styling just ships by
 * default.
 *
 * Every component is also available as a one-file module under
 * `./components/<name>/component.js` if you prefer to import them individually.
 *
 * Some components reference CSS custom properties (e.g. `--color-gray-*`,
 * `--color-blue`) that the Base UI docs define globally. Import `theme.css`
 * (or define equivalents yourself) so those components render as intended.
 */

// Disclosure
export { Accordion } from './components/accordion/component.js';
export { Collapsible } from './components/collapsible/component.js';

// Data display
export { Avatar } from './components/avatar/component.js';

// Buttons & inputs
export { Button } from './components/button/component.js';
export { Checkbox } from './components/checkbox/component.js';
export { CheckboxGroup } from './components/checkbox-group/component.js';
export { Input } from './components/input/component.js';
export { NumberField } from './components/number-field/component.js';
export { OTPField } from './components/otp-field/component.js';
export { Radio, RadioGroup } from './components/radio/component.js';
export { Slider } from './components/slider/component.js';
export { Switch } from './components/switch/component.js';
export { Toggle } from './components/toggle/component.js';
export { ToggleGroup } from './components/toggle-group/component.js';

// Forms
export { Field } from './components/field/component.js';
export { Fieldset } from './components/fieldset/component.js';
export { Form } from './components/form/component.js';

// Selection / pickers
export { Autocomplete } from './components/autocomplete/component.js';
export { Combobox } from './components/combobox/component.js';
export { Select } from './components/select/component.js';

// Navigation & menus
export { Menu } from './components/menu/component.js';
export { Menubar } from './components/menubar/component.js';
export { ContextMenu } from './components/context-menu/component.js';
export { NavigationMenu } from './components/navigation-menu/component.js';
export { Toolbar } from './components/toolbar/component.js';

// Layout
export { ScrollArea } from './components/scroll-area/component.js';
export { Separator } from './components/separator/component.js';
export { Tabs } from './components/tabs/component.js';

// Feedback & status
export { Meter } from './components/meter/component.js';
export { Progress } from './components/progress/component.js';
export { Toast } from './components/toast/component.js';

// Overlays
export { AlertDialog } from './components/alert-dialog/component.js';
export { Dialog } from './components/dialog/component.js';
export { Drawer } from './components/drawer/component.js';
export { Popover } from './components/popover/component.js';
export { PreviewCard } from './components/preview-card/component.js';
export { Tooltip } from './components/tooltip/component.js';
