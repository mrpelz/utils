/**
 * Drawer — styled wrapper around `@base-ui/react/drawer`.
 *
 * The common-ground styled parts (shared across every example on the Base UI
 * Drawer documentation page) live in `./common.js` and are re-exported here —
 * see that file for why they aren't defined directly in this one. Everything
 * is expressed with the design tokens from `../../theme.css` (`--surface`,
 * `--border`, `--muted`, `--popup-shadow`, motion tokens, …) rather than literal
 * colors, so dark mode falls out of the global ramp flip and the whole look is
 * themeable from one place.
 *
 * The parts that vary per example — chiefly `Backdrop`/`Viewport`/`Popup`
 * (position, transform, swipe/snap/indent behaviour) plus example-specific
 * extras (drag handles, nav panels, swipe areas) — live under `./variants/`:
 *   - `./variants/main`                    the primary right-side drawer demo
 *   - `./variants/position`                bottom-sheet positioning
 *   - `./variants/nested`                  stacked nested drawers
 *   - `./variants/snap-points`             snap-point bottom sheet with drag area
 *   - `./variants/virtual-keyboard-aware`  keyboard-aware sheet with a sticky footer input
 *   - `./variants/indent-effect`           background indent effect
 *   - `./variants/non-modal`               non-modal drawer
 *   - `./variants/mobile-navigation`       full-screen mobile nav sheet
 *   - `./variants/swipe-to-open`           edge swipe-to-open affordance
 *   - `./variants/close-confirmation`      nested confirmation dialog on discard
 *   - `./variants/action-sheet-with-separate-destructive-action`
 *     action sheet with a separated destructive action
 *
 * Each variant composes `CommonDrawer` and adds only what's unique to it. The
 * public `Drawer` export carries every variant under `Drawer.variants`.
 */
import { CommonDrawer } from './common.js';
import { actionSheetWithSeparateDestructiveAction } from './variants/action-sheet-with-separate-destructive-action.js';
import { closeConfirmation } from './variants/close-confirmation.js';
import { indentEffect } from './variants/indent-effect.js';
import { main } from './variants/main.js';
import { mobileNavigation } from './variants/mobile-navigation.js';
import { nested } from './variants/nested.js';
import { nonModal } from './variants/non-modal.js';
import { position } from './variants/position.js';
import { snapPoints } from './variants/snap-points.js';
import { swipeToOpen } from './variants/swipe-to-open.js';
import { virtualKeyboardAware } from './variants/virtual-keyboard-aware.js';

/**
 * All documented example variants for Drawer, grouped for convenient access:
 *
 *   import { Drawer } from 'base-ui-styled';
 *   Drawer.variants.mobileNavigation.Popup // the mobile-nav popup styling
 *
 * Each variant re-exports the common parts plus the styled parts unique to that
 * example. They're also importable directly, e.g.
 *   import { mobileNavigation } from '.../drawer/variants/mobile-navigation.js';
 */
export const variants = {
  main,
  position,
  nested,
  snapPoints,
  virtualKeyboardAware,
  indentEffect,
  nonModal,
  mobileNavigation,
  swipeToOpen,
  closeConfirmation,
  actionSheetWithSeparateDestructiveAction,
};

/**
 * The public Drawer export: the common-ground parts, with every documented
 * example variant reachable under `Drawer.variants`. Import from the package
 * root: `import { Drawer } from 'base-ui-styled'`.
 */
export const Drawer = {
  ...CommonDrawer,
  variants,
};

export { drawerButtonStyles, CommonDrawer } from './common.js';
