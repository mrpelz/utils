/**
 * Accordion — styled wrapper around `@base-ui/react/accordion`.
 *
 * The common-ground styled parts shared across every example on the Base UI
 * Accordion documentation page live in `./common.js` and are re-exported here
 * — see that file for why they aren't defined directly in this one. The
 * Accordion page's two examples (the primary demo and "open multiple panels")
 * use identical styling and differ only by a runtime `multiple` prop, so both
 * variants re-export the common ground unchanged:
 *   - `./variants/main`           the primary single-open demo
 *   - `./variants/open-multiple`  allows several panels open at once
 *
 * The example ships a plus/close icon that rotates when its panel opens; it's
 * re-exported as `Accordion.Icon`.
 */
import { CommonAccordion } from './common.js';
import { main } from './variants/main.js';
import { openMultiple } from './variants/open-multiple.js';

export const variants = {
  main,
  openMultiple,
};

export const Accordion = {
  ...CommonAccordion,
  variants,
};

export { CommonAccordion } from './common.js';
