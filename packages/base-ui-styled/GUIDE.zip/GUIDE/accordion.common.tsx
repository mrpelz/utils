/**
 * Accordion — the common-ground styled parts, factored out of `component.tsx`.
 *
 * This split exists purely to break a module cycle: `component.tsx` imports
 * every variant (to assemble `variants`/`Accordion`), and every variant
 * imports `CommonAccordion`. If `CommonAccordion` were defined directly in
 * `component.tsx`, that file's own top-level `import`s of the variants would
 * run — and each variant would try to read `CommonAccordion` — before
 * `component.tsx` ever reaches its own `CommonAccordion` declaration,
 * throwing a "Cannot access 'CommonAccordion' before initialization" TDZ
 * error under real ESM. Variants import `CommonAccordion` from here instead,
 * which has no dependency on `component.tsx` or the variants, so the cycle
 * never forms. `component.tsx` re-exports everything from here, so the public
 * import path (`from 'base-ui-styled/.../accordion/component.js'`) is
 * unaffected.
 */
import { Accordion as BaseAccordion } from '@base-ui/react/accordion';
import styled from '@emotion/styled';
import * as React from 'react';

const Root = styled(BaseAccordion.Root)`
  display: flex;
  width: 100%;
  max-width: 20rem;
  box-sizing: border-box;
  flex-direction: column;
  border: var(--border-width) solid var(--border);
  color: var(--on-surface);
`;

const Item = styled(BaseAccordion.Item)`
  & + & {
    border-top: var(--border-width) solid var(--border);
  }
`;

const Header = styled(BaseAccordion.Header)`
  margin: 0;
`;

/**
 * The rotating plus icon. `styled('svg')` so the open-state rotation can be
 * targeted from the trigger via `[data-panel-open] > &`.
 */
const StyledIcon = styled('svg')`
  flex-shrink: 0;
  transition: transform var(--duration-fast) ease-out;

  [data-panel-open] > & {
    transform: rotate(45deg);
  }
`;

const Icon = React.forwardRef<SVGSVGElement, React.ComponentProps<'svg'>>(
  ({ style, ...props }, ref) => (
    <StyledIcon
      ref={ref}
      fill="none"
      height="16"
      stroke="currentColor"
      strokeLinecap="square"
      strokeLinejoin="round"
      viewBox="0 0 16 16"
      width="16"
      {...props}
      style={{
        display: 'block',
        ...(typeof style === 'object' && style),
      }}
    >
      <path d="M1.5 8h13M8 14.5v-13" />
    </StyledIcon>
  ),
);

const Trigger = styled(BaseAccordion.Trigger)`
  display: flex;
  width: 100%;
  box-sizing: border-box;
  align-items: center;
  justify-content: space-between;
  padding: var(--space-2) var(--space-3);
  border: none;
  border-radius: 0;
  margin: 0;
  background-color: transparent;
  color: var(--on-surface);
  font-family: inherit;
  font-size: var(--text-sm);
  font-weight: var(--font-regular);
  gap: var(--space-4);
  line-height: var(--leading-sm);
  text-align: left;
  user-select: none;

  @media (hover: hover) {
    &:hover:not([data-disabled]) {
      background-color: var(--hover-wash);
    }
  }

  &:focus-visible {
    position: relative;
    z-index: 1;
    outline: var(--focus-ring-width) solid var(--focus-ring-color);
  }
`;

const Panel = styled(BaseAccordion.Panel)`
  overflow: hidden;
  height: var(--accordion-panel-height);
  box-sizing: border-box;
  font-size: var(--text-sm);
  line-height: var(--leading-sm);
  transition: height var(--duration-medium) ease-out;

  &[data-starting-style],
  &[data-ending-style] {
    height: 0;
  }
`;

/** Inner padding wrapper placed inside `Accordion.Panel` in the example. */
const Content = styled('div')`
  padding: var(--space-2) var(--space-3);
`;

export const CommonAccordion = {
  ...BaseAccordion,
  Root,
  Item,
  Header,
  Trigger,
  Panel,
  Icon,
  Content,
};
