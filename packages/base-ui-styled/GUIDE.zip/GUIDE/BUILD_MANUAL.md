# base-ui-styled — Component Build Manual

This is a **complete, self-contained** guide for building the remaining
components of `base-ui-styled`. You do not need any other context. Follow it
literally. Two components are already finished — **Drawer** and **Accordion** —
and this manual explains the exact pattern they follow so you can reproduce it
for every other component. A **sanity-check** section at the end lets you verify
your understanding against those two before you start.

---

## 1. What this library is

`base-ui-styled` wraps every [Base UI](https://base-ui.com) React component with
[`@emotion/styled`](https://emotion.sh) and pre-styles it to match the look from
Base UI's own documentation examples. The original Base UI API is preserved
(all parts, props, refs, the `render` prop, and every `data-*` state attribute),
so each styled component is a drop-in replacement for the unstyled original.

Styling is **expressed entirely with design tokens** defined in
`src/theme.css` (listed in §3). Do **not** write literal colors. This is what
makes the components themeable and keeps dark mode automatic.

---

## 2. The required file structure (per component)

Every component lives in `src/components/<dash-name>/` and MUST have this shape:

```
src/components/<dash-name>/
  common.tsx                ← the "common ground": shared styled parts, exports Common<Name>
  component.tsx             ← re-exports Common<Name> + assembles variants + the public export
  variants/
    main.tsx                ← the FIRST documentation example (the primary demo)
    <variant-name>.tsx      ← one file per ADDITIONAL documented example
```

Rules:

- **`<dash-name>`** is the component name in dash-case, matching the Base UI docs
  URL slug. Examples: `alert-dialog`, `number-field`, `scroll-area`,
  `context-menu`. (The full list is in §8.)
- **`variants/main.tsx`** is ALWAYS the page's first/primary demo (the one with
  no heading of its own).
- Each additional example on the docs page (the ones under `## Examples` with
  headings like "Position", "Snap points", "Undo action") becomes its own file
  `variants/<dash-name-of-heading>.tsx`.
- **Create a variant file even when its styling is identical to the primary
  demo.** Near-empty variants are intentional scaffolding for later manual
  customization. (Accordion's `open-multiple` is exactly this case — see §7.)
- Every relative import ends in **`.js`** (not `.tsx`), because the compiled
  output is `.js`. The files on disk stay `.tsx`; only the import specifier says
  `.js`.

### 2.0 Why `common.tsx` is a separate file from `component.tsx`

This is the one place this manual's structure is **not** the naive/obvious one,
and it matters: if `Common<Name>` were defined directly inside `component.tsx`
(which also imports every variant to build `variants`), you get a circular ES
module import — `component.tsx` → `variants/*.tsx` → back to `component.tsx` for
`Common<Name>`. Under real ESM this throws
`ReferenceError: Cannot access 'Common<Name>' before initialization` the moment
anything imports the component, because `component.tsx`'s own top-level
`import`s of the variants run — and each variant tries to read `Common<Name>` —
*before* `component.tsx` ever reaches its own `Common<Name>` declaration. This
isn't a style nitpick; it's a hard crash, verified by bundling and executing the
real output. Splitting the common ground into its own `common.tsx` (which has
**no** dependency on `component.tsx` or any variant) breaks the cycle: variants
import `Common<Name>` from `../common.js`, `component.tsx` imports it from
`./common.js` and re-exports it, and nothing ever needs something that isn't
ready yet. The public import path (`from '.../<dash-name>/component.js'`) is
unchanged — this is purely an internal wiring detail.

### 2.1 What goes in `common.tsx` (the "common ground")

The common ground is the **intersection** of all the examples' styling — the
parts whose CSS is *identical across every example on the page*. Put those
styled parts here. If a part's styling **differs between examples** (a very
common case for `Popup`, `Viewport`, `Positioner`, `List`, `Item`), it does
**not** belong in `common.tsx`; it belongs in each variant file instead. If a
part is identical in *most* examples but one outlier adds a small addition (e.g.
one example centers a `Title` that's otherwise identical everywhere), keep the
shared version in `common.tsx` and let the outlier variant define its own local
override — don't force a part into the common ground that isn't 100% identical
everywhere, and don't fragment a part that's 95% shared into N near-duplicate
copies either. Use judgment and say so in a comment.

`common.tsx` exports exactly one thing:

1. **`Common<Name>`** — an object spreading Base UI's namespace plus the shared
   styled parts. Variants (and `component.tsx`) import this.

Skeleton (replace `Drawer`/`drawer` with your component):

```tsx
import styled from '@emotion/styled';
import { Drawer as BaseDrawer } from '@base-ui/react/drawer';

// —— shared styled parts (only those identical across ALL examples) ——
const Trigger = styled(BaseDrawer.Trigger)`
  /* …token-based CSS… */
`;
// …more shared parts…

export const CommonDrawer = {
  ...BaseDrawer,
  Trigger,
  // …shared parts…
};
```

Notes:
- Spreading `...BaseDrawer` first keeps every un-styled part and sub-namespace
  available and behaving exactly as in Base UI.
- If several parts share one block of CSS (e.g. a Trigger and a Close that both
  use the same button styling), factor that block into an `@emotion/react` `css`
  helper and apply it to both. Export it if variants also need it. Example from
  Drawer: `export const drawerButtonStyles = css\`…\`;`.

### 2.2 What goes in `component.tsx`

`component.tsx` imports `Common<Name>` from `./common.js` and every variant from
`./variants/*.js`, and exports three things:

1. **`Common<Name>`** — re-exported from `./common.js` (`export { CommonDrawer }
   from './common.js';`), so it's importable from the public path too.
2. **`variants`** — an object mapping each variant's identifier to its export
   (see §2.3 for the identifier naming).
3. **`<Name>`** — the public export: `{ ...Common<Name>, variants }`.

Skeleton:

```tsx
import { CommonDrawer } from './common.js';
import { main } from './variants/main.js';
import { position } from './variants/position.js';
// …one import per variant…

export { CommonDrawer };

export const variants = {
  main,
  position,
  // …all variants…
};

export const Drawer = {
  ...CommonDrawer,
  variants,
};
```

### 2.3 What goes in each `variants/<name>.tsx`

A variant file:
1. Imports `Common<Name>` from `../common.js` (**not** `../component.js` — see
   §2.0 for why).
2. Defines only the styled parts that are **unique to this example** (the parts
   whose CSS differs from the common ground, plus any extra helper elements the
   example introduces — drag handles, nav panels, icons, etc.).
3. Exports a single object named with the variant's **camelCase identifier**,
   spreading the common ground and adding its unique parts.

The identifier is the dash-case filename converted to camelCase:
- `main.tsx` → `export const main`
- `snap-points.tsx` → `export const snapPoints`
- `mobile-navigation.tsx` → `export const mobileNavigation`
- `open-multiple.tsx` → `export const openMultiple`

Skeleton:

```tsx
import styled from '@emotion/styled';
import { Drawer as BaseDrawer } from '@base-ui/react/drawer';
import { CommonDrawer } from '../common.js';

const Popup = styled(BaseDrawer.Popup)`
  /* …styling unique to THIS example, token-based… */
`;

export const snapPoints = {
  ...CommonDrawer,
  Popup,
  // …other parts unique to this example…
};
```

If a variant's styling is identical to the primary demo (no unique parts), it is
just:

```tsx
import { CommonDrawer } from '../common.js';

export const openMultiple = {
  ...CommonDrawer,
};
```

---

## 3. The design tokens (use these — never literal colors or literal dimensions)

Colors live in `src/theme.css`; spacing, typography, sizing, border-width,
focus-ring dimensions, and motion live in `src/common.css`. The split is exactly
that distinction: `theme.css` is everything that changes between light and dark
mode (and flips automatically via the neutral ramp); `common.css` is everything
that doesn't. Both are imported once at the app root; reference tokens from
either as `var(--token)`.

### 3.0 `src/theme.css` — colors

**Neutral ramp** (flips automatically in dark mode — `--color-gray-50` is
lightest in light mode, darkest in dark mode):
`--color-gray-50`, `--color-gray-100`, `--color-gray-200`, `--color-gray-300`,
`--color-gray-400`, `--color-gray-500`, `--color-gray-600`, `--color-gray-700`,
`--color-gray-800`, `--color-gray-900`.

**Accent / semantic hues:** `--color-blue`, `--color-red`, `--color-green`.

**Semantic surface roles** (derived from the ramp, so they invert automatically):
| Token | Meaning |
| :-- | :-- |
| `--surface` | background of controls, inputs, popups |
| `--on-surface` | text/foreground on a surface |
| `--border` | default borders and dividers |
| `--border-muted` | subtle/light dividers |
| `--ink` | a filled/inverted control (checked box, pressed toggle) |
| `--on-ink` | text/icon sitting on an inked control |
| `--muted` | secondary text |
| `--subtle` | placeholder / disabled text |
| `--hover-wash` | hover background for ghost/outlined controls |
| `--active-wash` | active/pressed background |

**Elevation:** `--popup-shadow` (a drop shadow in light mode, `none` in dark).

**Focus ring:** `--focus-ring-color`, `--focus-ring-width`, `--focus-ring-offset`.

### 3.1 `src/common.css` — dimensions

Nothing here changes between light and dark mode.

**Spacing scale** (use for `gap`, `padding`/`padding-*`, `margin`/`margin-*` —
including inside `calc()` — and for element sizing when the value matches):

| Token | Value | Token | Value |
| :-- | :-- | :-- | :-- |
| `--space-0-5` | 0.125rem | `--space-5` | 1.25rem |
| `--space-1` | 0.25rem | `--space-6` | 1.5rem |
| `--space-1-5` | 0.375rem | `--space-8` | 2rem |
| `--space-2` | 0.5rem | `--space-9` | 2.25rem |
| `--space-2-5` | 0.625rem | `--space-10` | 2.5rem |
| `--space-3` | 0.75rem | `--space-12` | 3rem |
| `--space-4` | 1rem | | |

**Typography:**

| Token | Value | Token | Value |
| :-- | :-- | :-- | :-- |
| `--text-xs` | 0.75rem | `--leading-none` | 1 |
| `--text-sm` | 0.875rem | `--leading-xs` | 1rem |
| `--text-md` | 1rem | `--leading-sm` | 1.25rem |
| `--text-lg` | 1.25rem | `--leading-md` | 1.5rem |
| `--text-xl` | 1.5rem | `--font-regular` / `--font-bold` | 400 / 700 |

**Control/component sizing:** `--control-height` (2rem, the near-universal
button/input/trigger height), `--control-height-lg` (2.5rem, a larger control),
`--control-width-sm` (16rem, the combobox/autocomplete-style input-group
width convention), `--popup-width-sm` (24rem, the small-centered-dialog width
convention).

**Borders:** `--border-width` (1px) — use for `border`/`border-*` widths
(`border: var(--border-width) solid var(--border);`) and standalone
hairline-divider `width`/`height` (e.g. a 1px-tall separator `<div>`).

**Focus ring dimensions:** `--focus-ring-width` (2px), `--focus-ring-offset`
(-1px, inset rings), `--focus-ring-offset-outward` (2px, for rings that sit
outside the element — small/circular controls like a slider thumb). The color,
`--focus-ring-color`, is ramp-derived and lives in `theme.css`.

**Motion:** `--ease-out-fast`, `--ease-drawer`, `--duration-fast` (100ms),
`--duration-medium` (150ms), `--duration-slow` (450ms).

#### 3.1.1 Dimension mapping cheat-sheet

Convert literal dimension values the same way literal colors are converted —
whenever a value in the docs' CSS **exactly** matches a token's value, replace
it. Never round or approximate to the "nearest" token; if a value doesn't match
exactly, leave it as a literal.

- `font-size`, `line-height`, `font-weight` → the matching `--text-*` /
  `--leading-*` / `--font-*` token, always (these never mean anything other than
  typography).
- `gap`, `padding`/`padding-*`, `margin`/`margin-*` (including values embedded in
  `calc()`, and custom-property definitions that just hold a spacing value, e.g.
  `--bleed: 3rem;` → `--bleed: var(--space-12);`) → the matching `--space-*`
  token.
- `border`/`border-*`: `1px solid <color>` → `var(--border-width) solid
  var(--color-token)`.
- `height`/`width`/`min-*`/`max-*` of exactly `2rem`, `2.5rem`, `16rem`, or
  `24rem` are the one case that needs **judgment, not a mechanical rule**: use
  `--control-height` / `--control-height-lg` / `--control-width-sm` /
  `--popup-width-sm` only when the element genuinely fits that semantic role (a
  button, input, trigger, or small dialog). If a value merely happens to equal
  2rem for an unrelated reason (an avatar's diameter, a drag handle's length),
  use the plain `--space-*` scale token instead, or leave it literal if it
  doesn't recur.
- Leave `transition`/`animation` timing values alone — motion choreography is
  intentionally out of scope for dimension tokenization; only touch a
  `transition`'s duration if it already matches `--duration-fast/medium/slow`
  from an earlier pass.
- Leave `border-radius` alone.

### 3.2 Color token mapping cheat-sheet

Base UI's CSS-Modules examples use literal `oklch()` values and per-rule
`@media (prefers-color-scheme: dark)` overrides. Convert them like this:

| Literal in the docs | Replace with |
| :-- | :-- |
| `white` (as a control/popup background) | `var(--surface)` |
| `white` (as text/icon on an inked control) | `var(--on-ink)` |
| `oklch(14.5% 0 0deg)` (text) | `var(--on-surface)` |
| `oklch(14.5% 0 0deg)` (border) | `var(--border)` |
| `oklch(14.5% 0 0deg)` (filled bg) | `var(--ink)` |
| `oklch(43.9% 0 0deg)` | `var(--muted)` |
| `oklch(55.6% 0 0deg)` | `var(--subtle)` |
| `oklch(97% 0 0deg)` | `var(--hover-wash)` |
| `oklch(92.2% 0 0deg)` | `var(--active-wash)` |
| `oklch(87% 0 0deg)` | `var(--border-muted)` |
| `0.25rem 0.25rem 0 rgb(0 0 0 / 12%)` | `var(--popup-shadow)` |
| `2px solid oklch(14.5% …)` (focus) | `var(--focus-ring-width) solid var(--focus-ring-color)` |
| `outline-offset: -1px` | `outline-offset: var(--focus-ring-offset)` |
| `100ms`/`150ms`/`450ms` easings/durations | the matching `--duration-*` / `--ease-*` |
| `--color-gray-*`, `--color-blue`, etc. (already tokens in docs) | keep as-is |

**Then DELETE the now-redundant `@media (prefers-color-scheme: dark)` blocks.**
Because the ramp flips in dark mode, any dark block that only re-set a color you
just tokenized is a no-op — remove it. KEEP dark blocks that set something
structural and non-color (e.g. `--backdrop-opacity: 0.7`, or a literal
`box-shadow` that isn't `--popup-shadow`).

Some component examples already reference tokens like `--color-gray-900` /
`--color-blue` directly (Switch, Slider, Tabs, Progress, Number Field). Those
are already correct — leave them.

If an example genuinely needs a role no token covers, add a new token to
`theme.css` (light value in `:root`, and — only if it is NOT ramp-derived — a
dark value in the `@media (prefers-color-scheme: dark)` block). Prefer reusing
existing tokens.

---

## 4. Where to get each component's styling

Each docs page has a Markdown mirror at:

```
https://base-ui.com/react/components/<dash-name>.md
```

That page contains, for every example, a **"CSS Modules"** code block (a
`.module.css`) and a matching `.tsx`. Use the **CSS Modules** block (NOT the
Tailwind block). The class names in it map to Base UI parts by name:
`.Root`→`Root`, `.Trigger`→`Trigger`, `.Popup`→`Popup`, etc. Classes with no
matching part (e.g. `.Actions`, `.Handle`, `.Text`, `.Icon`) are helper elements
— re-export them as styled `div`/`span`/`svg`/`label` on the component object so
the documented look is available.

The page's structure tells you the variants:
- The first "Demo" block (before `## Examples`) → `variants/main.tsx`.
- Each heading under `## Examples` that has its own Demo/CSS-Modules block → its
  own variant file, named by dash-casing the heading.

To find the common ground: line up the CSS-Modules blocks from all examples and
keep, in `common.tsx`, only the rules that are identical everywhere. Anything
that differs goes into the individual variant files.

---

## 5. The barrel (`src/index.ts`)

Every component is exported from the barrel by importing its **`component.js`**
(NOT a variant). One line per component:

```ts
export { Drawer } from './components/drawer/component.js';
export { Accordion } from './components/accordion/component.js';
```

Radio's line also exports `RadioGroup`:
`export { Radio, RadioGroup } from './components/radio/component.js';`

Do not change existing lines except to point them at `component.js` once you've
built that component. The public name is PascalCase (see §8).

---

## 6. Worked reference — Drawer (styling DIFFERS between examples)

Drawer's page currently has 11 examples with full Demo/CSS-Modules blocks (the
live docs page grows over time — always re-derive the count from the actual
page per §9, don't assume a number from this manual). Its `Viewport` and
`Popup` differ in every one (right-side vs bottom-sheet vs snap vs indent…), so
those are NOT in the common ground. `Trigger`, `Close`, `Backdrop`, `Content`,
`Title`, `Description` are identical across the examples that use a
viewport-fixed drawer → those live in `common.tsx`. (A few outlier examples
redefine `Backdrop`/`Title`/`Description` locally where their layout genuinely
needs something different — e.g. a bottom sheet centers its `Title`; that's the
"common but one outlier overrides locally" case from §2.1, not a sign the part
doesn't belong in the common ground.)

Structure produced:
```
drawer/
  common.tsx                        (exports CommonDrawer + the shared css
                                     helper drawerButtonStyles)
  component.tsx                     (re-exports CommonDrawer, exports
                                     variants, Drawer)
  variants/
    main.tsx                                        → main            (right-side)
    position.tsx                                     → position        (bottom sheet)
    nested.tsx                                        → nested
    snap-points.tsx                                   → snapPoints
    virtual-keyboard-aware.tsx                        → virtualKeyboardAware
    indent-effect.tsx                                 → indentEffect
    non-modal.tsx                                      → nonModal
    mobile-navigation.tsx                              → mobileNavigation
    swipe-to-open.tsx                                  → swipeToOpen
    close-confirmation.tsx                             → closeConfirmation
    action-sheet-with-separate-destructive-action.tsx  → actionSheetWithSeparateDestructiveAction
```

A representative variant file (`variants/main.tsx`), showing the exact import
and export shape you must reproduce:

```tsx
import styled from '@emotion/styled';
import { Drawer as BaseDrawer } from '@base-ui/react/drawer';
import { CommonDrawer } from '../common.js';

const Viewport = styled(BaseDrawer.Viewport)`
  --viewport-padding: 0px;
  position: fixed;
  inset: 0;
  display: flex;
  justify-content: flex-end;
  padding: var(--viewport-padding);

  @supports (-webkit-touch-callout: none) {
    --viewport-padding: var(--space-2-5);
  }
`;

const Popup = styled(BaseDrawer.Popup)`
  --bleed: var(--space-12);
  box-sizing: border-box;
  width: calc(20rem + var(--bleed));
  /* …structural rules… */
  border-left: var(--border-width) solid var(--border);
  background-color: var(--surface);
  color: var(--on-surface);
  box-shadow: var(--popup-shadow);
  transition: transform var(--duration-slow) var(--ease-drawer);
  transform: translateX(var(--drawer-swipe-movement-x));
`;

const Actions = styled('div')`
  display: flex;
  justify-content: flex-end;
  gap: var(--space-3);
`;

export const main = {
  ...CommonDrawer,
  Viewport,
  Popup,
  Actions,
};
```

Note: colors AND dimensions are tokens (`--bleed`'s *value*, `3rem`, is
tokenized to `var(--space-12)`, but the custom property name `--bleed` itself,
plus `--viewport-padding` and the `--drawer-swipe-*` family, are Base UI's own
runtime variables and structural locals — keep those names as-is).

---

## 7. Worked reference — Accordion (styling IDENTICAL between examples)

Accordion's page has 2 examples: the primary demo and "Open multiple panels".
Their CSS is byte-identical; the second only adds a runtime `multiple` prop. So
ALL styled parts are common ground (they live in `common.tsx`), and BOTH
variant files are thin re-exports.

Structure produced:
```
accordion/
  common.tsx                    (exports CommonAccordion; styled parts: Root,
                                 Item, Header, Trigger, Panel, Icon, Content)
  component.tsx                 (re-exports CommonAccordion, exports
                                 variants, Accordion)
  variants/
    main.tsx           → export const main         (re-export only)
    open-multiple.tsx  → export const openMultiple  (re-export only)
```

Both variant files are exactly this (only the identifier differs):

```tsx
import { CommonAccordion } from '../common.js';

export const main = {
  ...CommonAccordion,
};
```

This is the intended shape for "empty" variants — they exist as scaffolding so
customizations can be added later without restructuring.

The rotating plus icon in the example is a helper element with no Base UI part,
so it's re-exported as `Accordion.Icon` — a `React.forwardRef` SVG whose
`styled('svg')` wrapper carries the open-state rotation
(`[data-panel-open] > & { transform: rotate(45deg); }`) and uses
`var(--duration-fast)` for its transition. Note also: this SVG wrapper's
`style={{ display: 'block', ...props.style }}` pattern needs a small guard
under this repo's `strictNullChecks` — preact's `style` prop type includes
`string`, so spreading it directly fails to typecheck. Destructure it out and
guard the type instead:
`style={{ display: 'block', ...(typeof style === 'object' && style) }}`
(with `{ style, ...props }` in the function signature).

---

## 8. Component roster (dash-name → PascalCase export)

Build every one of these (Drawer and Accordion are already done). For each, the
docs page is `https://base-ui.com/react/components/<dash-name>.md`.

| dash-name | export(s) |
| :-- | :-- |
| accordion | Accordion ✅ done |
| alert-dialog | AlertDialog |
| autocomplete | Autocomplete |
| avatar | Avatar |
| button | Button |
| checkbox | Checkbox |
| checkbox-group | CheckboxGroup |
| collapsible | Collapsible |
| combobox | Combobox |
| context-menu | ContextMenu |
| dialog | Dialog |
| drawer | Drawer ✅ done |
| field | Field |
| fieldset | Fieldset |
| form | Form |
| input | Input |
| menu | Menu |
| menubar | Menubar |
| meter | Meter |
| navigation-menu | NavigationMenu |
| number-field | NumberField |
| otp-field | OTPField |
| popover | Popover |
| preview-card | PreviewCard |
| progress | Progress |
| radio | Radio, RadioGroup |
| scroll-area | ScrollArea |
| select | Select |
| separator | Separator |
| slider | Slider |
| switch | Switch |
| tabs | Tabs |
| toast | Toast |
| toggle | Toggle |
| toggle-group | ToggleGroup |
| toolbar | Toolbar |
| tooltip | Tooltip |

Special cases:
- **radio**: the `radio` page documents both `Radio` and `RadioGroup` (Base UI
  packages `@base-ui/react/radio` and `@base-ui/react/radio-group`). Put both in
  `radio/common.tsx`/`component.tsx` and export both; the barrel line exports
  both names.
- **Single-element components** (Button, Input, Form, Separator, Toggle,
  ToggleGroup, CheckboxGroup, Avatar's not this) render one element rather than a
  namespace of parts. For these, the "common ground" is the single styled
  element; still create `common.tsx` + `component.tsx` + `variants/main.tsx` (+
  any extra variants). If the component needs helper sub-parts, attach them with
  `Object.assign(StyledEl, { Label, … })`.
- Components whose examples compose OTHER components (e.g. a Toolbar example that
  embeds a Select, or an Autocomplete "command palette" that embeds Dialog +
  ScrollArea): only style the parts belonging to THIS component as the public
  API. Anything belonging to the embedded component is styled **locally within
  that one variant file** (not exported, not shared) — even if the embedded
  component already has its own finished directory elsewhere in this library,
  don't cross-import it; each demo's composed-part styling is usually bespoke to
  that one example anyway. See `drawer/variants/mobile-navigation.tsx` (embeds
  ScrollArea) and `drawer/variants/close-confirmation.tsx` (embeds AlertDialog)
  for the pattern.

---

## 9. Per-component procedure (do this for each)

1. Fetch the page with `curl -s https://base-ui.com/react/components/<dash-name>.md`
   — don't use a summarizing web-fetch tool, you need exact byte-for-byte CSS.
   Pages can be thousands of lines; grep for `^## \|^### ` first to map out the
   headings, then read specific sections by offset rather than the whole file.
2. List the examples: the first Demo = `main`; each `## Examples` heading with
   its own Demo **and** CSS-Modules block = a variant (dash-case the heading for
   the filename). A heading with only an inline code snippet and no Demo block
   is NOT a variant — skip it. Don't assume a fixed example count from this
   manual or from any other component's history; the live docs page is the
   source of truth and changes over time (re-derive it fresh every time).
3. For each example, take its **CSS Modules** block. Map class names → Base UI
   parts; note helper classes (no matching part) as extra styled elements.
4. Diff all examples' CSS. Identical rules → common ground (`common.tsx`).
   Differing parts + example-only helpers → that variant's file. If a part is
   identical in most examples but one outlier adds a small addition, keep the
   shared version in `common.tsx` and let the outlier override it locally (see
   §2.1) rather than fragmenting or over-generalizing.
5. Tokenize every color/shadow/focus/motion value per §3.0/§3.2, and every
   spacing/typography/sizing/border-width value per §3.1/§3.1.1. Delete
   redundant dark-mode color blocks (keep structural non-color ones). Never
   round a dimension to the "nearest" token — only substitute on an exact match.
6. Write `common.tsx` (exports `Common<Name>`, no dependency on `component.tsx`
   or any variant — see §2.0 for why this split is required, not optional) and
   `component.tsx` (imports `Common<Name>` from `./common.js`, imports every
   variant, exports `Common<Name>`, `variants`, `<Name>`). Write one
   `variants/*.tsx` per example, each importing `Common<Name>` from
   `../common.js` (not `../component.js`) and exporting its camelCase
   identifier. Empty variants are re-export-only.
7. Point the barrel line at `./components/<dash-name>/component.js`.
8. Run the checks in §10, including `npx stylelint --fix` then `npx stylelint`,
   `npx eslint --fix` then `npx eslint`, and `npx tsc --noEmit` (zero errors for
   your files) before considering the component done.

---

## 10. Sanity check (verify BEFORE and AFTER building)

**A. Verify your understanding against the finished components.** These
statements are all TRUE of the existing Drawer and Accordion. If your mental
model disagrees with any, re-read the referenced section:

1. `drawer/common.tsx` exports exactly one public object, `CommonDrawer`, plus
   one `css` helper `drawerButtonStyles`. `drawer/component.tsx` re-exports both
   and additionally exports `variants` and `Drawer`. (§2.1, §2.2, §6)
2. `drawer/common.tsx` does NOT define `Viewport` or `Popup` — those differ per
   example and live in the variant files. (§6)
3. Every file in `drawer/variants/` imports `{ CommonDrawer } from
   '../common.js'` (NOT `'../component.js'`) and exports one camelCase const.
   (§2.0, §2.3)
4. `accordion/common.tsx` DOES define all styled parts (Root, Item, Header,
   Trigger, Panel, Icon, Content) because Accordion's examples share styling.
   `accordion/component.tsx` just re-exports `CommonAccordion` and assembles
   `variants`/`Accordion`. (§7)
5. `accordion/variants/main.tsx` and `open-multiple.tsx` are re-export-only —
   they add no parts. (§7)
6. Neither component contains any literal `oklch(...)`, `white`, or `black`
   color for styling — only `var(--token)`. (The only allowed literal `white`
   is inside a multi-stop gradient, `white-space`/other CSS keywords that
   merely contain the letters are fine, and `black` is allowed specifically for
   full-viewport backdrop/scrim overlays, since no ramp token stays dark in both
   themes.) (§3.0, §3.2)
7. Neither component contains a literal dimension that exactly matches a
   `common.css` token's value — only `var(--space-*)`, `var(--text-*)`, etc.
   where applicable. Values that don't exactly match any token (including
   motion timing and border-radius, which are out of scope for tokenization)
   are left as literals. (§3.1, §3.1.1)
8. The barrel exports each from `component.js`, never from a variant. (§5)

**B. Mechanical checks on what you produced** (per component `<dash-name>`):

- [ ] `src/components/<dash-name>/common.tsx` exists, exports `Common<Name>`,
      and has NO import from `./component.js` or any `./variants/*.js` file.
- [ ] `src/components/<dash-name>/component.tsx` exists and exports
      `Common<Name>` (re-exported from `./common.js`), `variants`, and
      `<Name>`.
- [ ] `variants/main.tsx` exists and corresponds to the page's first demo.
- [ ] There is exactly one `variants/*.tsx` per documented example currently on
      the live docs page (re-checked fresh, not assumed from a prior count).
- [ ] Every variant file imports `Common<Name>` from `../common.js` (not
      `../component.js`) and exports one camelCase identifier matching its
      filename.
- [ ] Every relative import specifier ends in `.js`.
- [ ] `variants` in `component.tsx` lists every variant identifier, and each is
      imported at the top of `component.tsx`.
- [ ] No literal colors remain (`grep -nE "oklch\\(|#[0-9a-fA-F]{3,6}\\b" file`
      returns nothing for styling; `\\bwhite\\b`/`\\bblack\\b` only appear in
      gradients, non-color CSS keywords, or backdrop scrims).
- [ ] No literal dimension remains that exactly matches a `common.css` token
      value in a `gap`/`padding`/`margin`/`font-size`/`line-height`/
      `font-weight`/border-width context.
- [ ] No `@media (prefers-color-scheme: dark)` block remains that only re-sets a
      tokenized color (those are redundant after tokenization).
- [ ] The barrel line points at `./components/<dash-name>/component.js`.
- [ ] `<Name>` PascalCase matches §8.
- [ ] `npx stylelint`, `npx eslint`, and `npx tsc --noEmit -p tsconfig.json`
      (excluding any unrelated in-progress work elsewhere in the repo) are all
      clean for your files.

**C. Quick grep recipes** (run from `src/`):

```sh
# literal colors that should have been tokenized (expect no output):
grep -rnE "oklch\(|#[0-9a-fA-F]{3,6}\b" components/<dash-name>/

# literal dimensions that should have been tokenized (expect no/few matches):
grep -rnE "(font-size|line-height|font-weight): (0\.75rem|0\.875rem|1rem|1\.25rem|1\.5rem|400|700)\b|padding[a-z-]*: [^;]*\b(0\.125|0\.25|0\.375|0\.5|0\.625|0\.75|1\.25|1\.5|2\.25|2\.5)rem\b|gap: [^;]*\b(0\.125|0\.25|0\.375|0\.5|0\.625|0\.75|1\.25|1\.5|2\.25|2\.5)rem\b|border[a-z-]*: 1px solid" components/<dash-name>/

# common.tsx has no dependency on component.tsx or variants (expect no output):
grep -n "component.js\|variants/" components/<dash-name>/common.tsx

# every variant imports from common.js, not component.js (expect one line per file):
grep -rn "from '\.\./common.js'" components/<dash-name>/variants/

# barrel points at component.js (expect a match):
grep "components/<dash-name>/component.js" index.ts
```

---

## 11. Conventions recap

- Files are `.tsx` on disk; imports use `.js`.
- `common.tsx` holds the common ground and has zero dependency on
  `component.tsx` or any variant — this is required to avoid a circular-import
  TDZ crash (§2.0), not a stylistic choice.
- Colors/shadows/focus-ring-color → tokens from `theme.css` only.
  Spacing/typography/sizing/border-width/focus-ring-dimensions/motion → tokens
  from `common.css` only. Never round or approximate to the nearest token —
  only substitute on an exact value match.
- Preserve Base UI runtime CSS variables (`--accordion-panel-height`,
  `--drawer-swipe-*`, `--anchor-width`, `--available-height`, etc.) exactly —
  including custom-property *names* like `--bleed`, even when their *value*
  gets tokenized (`--bleed: var(--space-12);`).
- Keep `box-sizing`, layout, spacing, transitions' structural parts verbatim;
  only the *values* that correspond to tokens get swapped.
- Re-export helper elements (icons, layout wrappers, labels) so nothing from the
  demo is lost.
- One doc-comment at the top of each file explaining what it is and (for
  `component.tsx`) listing the variants.
- An icon `forwardRef` component that spreads a `style` prop needs
  `{ style, ...props }` destructured and
  `...(typeof style === 'object' && style)` guarded (not a bare
  `...props.style`) to typecheck under `strictNullChecks` — see §7's note.
