/**
 * Accordion — "open multiple panels" variant.
 *
 * https://base-ui.com/react/components/accordion#open-multiple-panels
 *
 * Styling is identical to the primary demo; this example differs only by the
 * runtime `multiple` prop on `<Accordion.Root>`, which lets several panels stay
 * open at once. Re-exports the common ground unchanged — pass `multiple`
 * yourself: `<Accordion.Root multiple>…</Accordion.Root>`.
 */
import { CommonAccordion } from '../common.js';

export const openMultiple = {
  ...CommonAccordion,
};
