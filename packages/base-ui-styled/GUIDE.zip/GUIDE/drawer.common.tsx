/**
 * Drawer — the common-ground styled parts, factored out of `component.tsx`.
 *
 * This split exists purely to break a module cycle: `component.tsx` imports
 * every variant (to assemble `variants`/`Drawer`), and every variant imports
 * `CommonDrawer`. If `CommonDrawer` were defined directly in `component.tsx`,
 * that file's own top-level `import`s of the variants would run — and each
 * variant would try to read `CommonDrawer` — before `component.tsx` ever
 * reaches its own `CommonDrawer` declaration, throwing a "Cannot access
 * 'CommonDrawer' before initialization" TDZ error under real ESM. Variants
 * import `CommonDrawer` from here instead, which has no dependency on
 * `component.tsx` or the variants, so the cycle never forms. `component.tsx`
 * re-exports everything from here, so the public import path
 * (`from 'base-ui-styled/.../drawer/component.js'`) is unaffected.
 */
import { Drawer as BaseDrawer } from '@base-ui/react/drawer';
import { css } from '@emotion/react';
import styled from '@emotion/styled';

/**
 * The `.Button` style shared by the trigger and close controls across every
 * Drawer example. Exposed as a reusable `css` block so variants that add their
 * own buttons can apply it too.
 */
export const drawerButtonStyles = css`
  display: flex;
  height: var(--control-height);
  box-sizing: border-box;
  align-items: center;
  justify-content: center;
  padding: 0 var(--space-3);
  border: var(--border-width) solid var(--border);
  margin: 0;
  background-color: var(--surface);
  color: var(--on-surface);
  font-family: inherit;
  font-size: var(--text-sm);
  font-weight: var(--font-regular);
  gap: var(--space-2);
  line-height: var(--leading-none);
  user-select: none;
  white-space: nowrap;

  @media (hover: hover) {
    &:hover:not([data-disabled]) {
      background-color: var(--hover-wash);
    }
  }

  &:focus-visible {
    outline: var(--focus-ring-width) solid var(--focus-ring-color);
    outline-offset: var(--focus-ring-offset);
  }

  &:active:not([data-disabled]) {
    background-color: var(--active-wash);
  }

  &[data-disabled] {
    border-color: var(--subtle);
    color: var(--subtle);
  }
`;

const Trigger = styled(BaseDrawer.Trigger)`
  ${drawerButtonStyles}
`;

const Close = styled(BaseDrawer.Close)`
  ${drawerButtonStyles}
`;

/**
 * Backdrop shared across the examples whose drawer is fixed to the viewport
 * (main, non-modal): opacity tracks swipe progress and fades on enter/exit.
 * Variants positioned differently (bottom sheets, the indent effect, swipe
 * areas) define their own `Backdrop`.
 */
const Backdrop = styled(BaseDrawer.Backdrop)`
  --backdrop-opacity: 0.2;
  --bleed: var(--space-12);

  position: fixed;
  min-height: 100dvh;
  background-color: black;
  inset: 0;
  opacity: calc(var(--backdrop-opacity) * (1 - var(--drawer-swipe-progress)));
  transition-duration: var(--duration-slow);
  transition-property: opacity;
  transition-timing-function: var(--ease-drawer);

  /* iOS 26+: cover the entire visual viewport. */
  @supports (-webkit-touch-callout: none) {
    position: absolute;
  }

  @media (prefers-color-scheme: dark) {
    --backdrop-opacity: 0.7;
  }

  &[data-starting-style],
  &[data-ending-style] {
    opacity: 0;
  }

  &[data-swiping] {
    transition-duration: 0ms;
  }

  &[data-ending-style] {
    transition-duration: calc(var(--drawer-swipe-strength) * 400ms);
  }
`;

/** Inner content wrapper, identical across examples. */
const Content = styled(BaseDrawer.Content)`
  width: 100%;
  max-width: 32rem;
  margin: 0 auto;
`;

const Title = styled(BaseDrawer.Title)`
  margin-top: 0;
  margin-bottom: var(--space-1);
  font-size: var(--text-md);
  font-weight: var(--font-bold);
  line-height: var(--leading-md);
`;

const Description = styled(BaseDrawer.Description)`
  margin: 0 0 var(--space-6);
  color: var(--muted);
  font-size: var(--text-sm);
  line-height: var(--leading-sm);
`;

/**
 * The common-ground Drawer: Base UI's parts plus the parts whose styling is
 * shared across every example. Variants import this and layer their own
 * example-specific parts on top.
 */
export const CommonDrawer = {
  ...BaseDrawer,
  Trigger,
  Close,
  Backdrop,
  Content,
  Title,
  Description,
};
