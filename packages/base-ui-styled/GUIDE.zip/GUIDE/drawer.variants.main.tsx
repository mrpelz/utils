/**
 * Drawer — "main" variant (the primary right-side drawer demo).
 *
 * https://base-ui.com/react/components/drawer (first example on the page)
 *
 * Adds only what's unique to this example on top of the shared parts in the
 * common ground in `../component`: a right-anchored `Viewport` and a `Popup`
 * that slides in from the right edge with an over-scroll "bleed", plus a
 * right-aligned `Actions` row. Re-exports the common parts so this file is a
 * complete, drop-in Drawer.
 */
import { Drawer as BaseDrawer } from '@base-ui/react/drawer';
import styled from '@emotion/styled';

import { CommonDrawer } from '../common.js';

const Viewport = styled(BaseDrawer.Viewport)`
  --viewport-padding: 0px;

  position: fixed;
  display: flex;
  justify-content: flex-end;
  padding: var(--viewport-padding);
  inset: 0;

  @supports (-webkit-touch-callout: none) {
    --viewport-padding: var(--space-2-5);
  }
`;

const Popup = styled(BaseDrawer.Popup)`
  --bleed: var(--space-12);

  width: calc(20rem + var(--bleed));
  max-width: calc(100vw - var(--space-12) + var(--bleed));
  height: 100%;
  box-sizing: border-box;
  padding: var(--space-6);
  padding-right: calc(var(--space-6) + var(--bleed));
  border-left: var(--border-width) solid var(--border);
  margin-right: calc(-1 * var(--bleed));
  background-color: var(--surface);
  box-shadow: var(--popup-shadow);
  color: var(--on-surface);
  outline: 0;
  overflow-y: auto;
  overscroll-behavior: contain;
  touch-action: auto;
  transform: translateX(var(--drawer-swipe-movement-x));
  transition: transform var(--duration-slow) var(--ease-drawer);
  will-change: transform;

  &[data-starting-style],
  &[data-ending-style] {
    transform: translateX(
      calc(100% - var(--bleed) + var(--viewport-padding) + 2px)
    );
  }

  &[data-ending-style] {
    transition-duration: calc(var(--drawer-swipe-strength) * 400ms);
  }

  @supports (-webkit-touch-callout: none) {
    --bleed: 0px;

    border: var(--border-width) solid var(--border);
    margin-right: 0;
  }
`;

/** Right-aligned row for the drawer's action buttons. */
const Actions = styled('div')`
  display: flex;
  justify-content: flex-end;
  gap: var(--space-3);
`;

export const main = {
  ...CommonDrawer,
  Viewport,
  Popup,
  Actions,
};
