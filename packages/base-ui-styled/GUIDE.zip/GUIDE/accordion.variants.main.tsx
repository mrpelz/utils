/**
 * Accordion — "main" variant (the primary single-open demo).
 *
 * https://base-ui.com/react/components/accordion (first example)
 *
 * The primary demo's styling is the common ground, so this variant simply
 * re-exports it. Use `<Accordion.Root>` without `multiple` for single-open
 * behaviour.
 */
import { CommonAccordion } from '../common.js';

export const main = {
  ...CommonAccordion,
};
